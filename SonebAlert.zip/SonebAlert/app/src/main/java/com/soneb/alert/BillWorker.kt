package com.soneb.alert

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class BillWorker(
    private val context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    private val tag = "BillWorker"
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            // Récupérer le numéro depuis inputData ou SharedPreferences
            val subscriber = inputData.getString("subscriber")
                ?: getSubscriberFromPrefs()

            if (subscriber.isNullOrEmpty()) {
                Log.w(tag, "Aucun numéro d'abonné. Worker arrêté.")
                return@withContext Result.success()
            }

            Log.d(tag, "Vérification facture pour : $subscriber")

            val unpaidAmount = fetchUnpaidAmount(subscriber)

            if (unpaidAmount > 0) {
                Log.d(tag, "Impayé détecté : $unpaidAmount FCFA")
                sendUnpaidNotification(subscriber, unpaidAmount)
            } else {
                Log.d(tag, "Aucun impayé. Pas de notification envoyée.")
            }

            Result.success()

        } catch (e: Exception) {
            Log.e(tag, "Erreur dans BillWorker : ${e.message}", e)
            // Retry uniquement pour les erreurs réseau transitoires
            if (runAttemptCount < 3) Result.retry()
            else Result.success() // Ne pas bloquer indéfiniment
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // APPEL API
    // ─────────────────────────────────────────────────────────────────────────

    private fun fetchUnpaidAmount(subscriberNumber: String): Long {
        val url = "https://soneb-api.service-public.bj/soneb/subscriber/bill?subscriber=$subscriberNumber"
        val request = Request.Builder().url(url).get().build()

        val response = client.newCall(request).execute()

        if (!response.isSuccessful) {
            Log.w(tag, "Réponse serveur non OK : ${response.code}")
            return -1L // Indique une erreur, pas d'impayé confirmé
        }

        val body = response.body?.string() ?: return 0L
        return parseUnpaidAmount(body)
    }

    private fun parseUnpaidAmount(jsonBody: String): Long {
        return try {
            val json = JSONObject(jsonBody)
            var totalUnpaid = 0L

            val bills = json.optJSONArray("bills") ?: json.optJSONArray("factures")

            if (bills != null) {
                for (i in 0 until bills.length()) {
                    val bill = bills.optJSONObject(i) ?: continue
                    val soldab = bill.optLong("soldab", 0L)
                        .coerceAtLeast(bill.optLong("solde", 0L))
                        .coerceAtLeast(bill.optLong("montant_impaye", 0L))
                        .coerceAtLeast(bill.optLong("amount_due", 0L))
                    if (soldab > 0) totalUnpaid += soldab
                }
            } else {
                // Réponse objet direct
                val soldab = json.optLong("soldab", 0L)
                    .coerceAtLeast(json.optLong("solde", 0L))
                if (soldab > 0) totalUnpaid = soldab
            }

            totalUnpaid
        } catch (e: Exception) {
            Log.e(tag, "Erreur parsing JSON : ${e.message}")
            0L
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // NOTIFICATION
    // ─────────────────────────────────────────────────────────────────────────

    private fun sendUnpaidNotification(subscriber: String, amount: Long) {
        try {
            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            }
            val pendingIntent = PendingIntent.getActivity(
                context, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val formattedAmount = String.format("%,d", amount).replace(',', ' ')

            val notification = NotificationCompat.Builder(context, "soneb_alert_channel")
                .setSmallIcon(R.drawable.ic_water_drop)
                .setContentTitle("⚠️ Facture SONEB impayée")
                .setContentText("Montant dû : $formattedAmount FCFA — Abonné : $subscriber")
                .setStyle(
                    NotificationCompat.BigTextStyle()
                        .bigText(
                            "Votre compte SONEB (Abonné : $subscriber) a un montant impayé " +
                                    "de $formattedAmount FCFA.\n\nPayez via les canaux officiels SONEB."
                        )
                )
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .setColor(0xFFC62828.toInt())
                .build()

            val manager =
                context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.notify(NOTIF_ID, notification)

        } catch (e: Exception) {
            Log.e(tag, "Erreur envoi notification : ${e.message}")
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // HELPERS
    // ─────────────────────────────────────────────────────────────────────────

    private fun getSubscriberFromPrefs(): String? {
        return try {
            context.getSharedPreferences("soneb_prefs", Context.MODE_PRIVATE)
                .getString("subscriber", null)
        } catch (e: Exception) {
            null
        }
    }

    companion object {
        private const val NOTIF_ID = 1001
    }
}
