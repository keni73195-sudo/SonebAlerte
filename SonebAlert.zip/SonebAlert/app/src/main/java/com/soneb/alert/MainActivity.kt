package com.soneb.alert

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.work.*
import com.soneb.alert.databinding.ActivityMainBinding
import okhttp3.*
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val prefs by lazy { getSharedPreferences("soneb_prefs", MODE_PRIVATE) }
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    // Launcher pour la permission notifications (Android 13+)
    private val notifPermLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) scheduleWeeklyWork()
        else Toast.makeText(
            this,
            "Notifications désactivées. Activez-les dans les paramètres.",
            Toast.LENGTH_LONG
        ).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        createNotificationChannel()
        restoreSavedSubscriber()
        setupClickListeners()
        restoreNotifSwitch()
    }

    // ─────────────────────────────────────────────────────────────────────────
    // UI SETUP
    // ─────────────────────────────────────────────────────────────────────────

    private fun restoreSavedSubscriber() {
        val saved = prefs.getString("subscriber", "") ?: ""
        if (saved.isNotEmpty()) {
            binding.etSubscriber.setText(saved)
        }
    }

    private fun restoreNotifSwitch() {
        val enabled = prefs.getBoolean("notif_enabled", true)
        binding.switchNotif.isChecked = enabled
    }

    private fun setupClickListeners() {

        // Bouton Vérifier
        binding.btnVerify.setOnClickListener {
            val number = binding.etSubscriber.text.toString().trim()
            if (number.isEmpty()) {
                binding.tilSubscriber.error = "Veuillez entrer votre numéro d'abonné"
                return@setOnClickListener
            }
            binding.tilSubscriber.error = null
            prefs.edit().putString("subscriber", number).apply()
            checkBill(number)
        }

        // Switch notifications
        binding.switchNotif.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("notif_enabled", isChecked).apply()
            if (isChecked) {
                requestNotificationPermissionAndSchedule()
            } else {
                WorkManager.getInstance(this).cancelUniqueWork("soneb_weekly_check")
                showToast("Alertes hebdomadaires désactivées")
            }
        }

        // WhatsApp
        binding.btnWhatsApp.setOnClickListener {
            openWhatsApp()
        }

        // Email
        binding.btnEmail.setOnClickListener {
            openEmail()
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // VÉRIFICATION FACTURE
    // ─────────────────────────────────────────────────────────────────────────

    private fun checkBill(subscriberNumber: String) {
        showLoading(true)
        hideResultCard()

        val url = "https://soneb-api.service-public.bj/soneb/subscriber/bill?subscriber=$subscriberNumber"
        val request = Request.Builder().url(url).get().build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    showLoading(false)
                    showError("Erreur réseau. Vérifiez votre connexion internet.")
                }
            }

            override fun onResponse(call: Call, response: Response) {
                runOnUiThread {
                    showLoading(false)
                    if (!response.isSuccessful) {
                        showError("Erreur serveur (${response.code}). Réessayez plus tard.")
                        return@runOnUiThread
                    }
                    try {
                        val body = response.body?.string() ?: ""
                        parseAndDisplayResult(body)
                    } catch (e: Exception) {
                        showError("Impossible de lire la réponse du serveur.")
                    }
                }
            }
        })
    }

    private fun parseAndDisplayResult(jsonBody: String) {
        try {
            val json = JSONObject(jsonBody)
            // Adapter selon la vraie structure de l'API SONEB
            val bills = json.optJSONArray("bills") ?: json.optJSONArray("factures")
            var totalUnpaid = 0L
            var unpaidCount = 0

            if (bills != null) {
                for (i in 0 until bills.length()) {
                    val bill = bills.optJSONObject(i) ?: continue
                    // Champs possibles : soldab, solde, montant_impaye, amount_due
                    val soldab = bill.optLong("soldab", 0L)
                        .coerceAtLeast(bill.optLong("solde", 0L))
                        .coerceAtLeast(bill.optLong("montant_impaye", 0L))
                        .coerceAtLeast(bill.optLong("amount_due", 0L))
                    if (soldab > 0) {
                        totalUnpaid += soldab
                        unpaidCount++
                    }
                }
            } else {
                // Si la réponse est un objet direct (pas un tableau)
                val soldab = json.optLong("soldab", 0L)
                    .coerceAtLeast(json.optLong("solde", 0L))
                if (soldab > 0) {
                    totalUnpaid = soldab
                    unpaidCount = 1
                }
            }

            if (totalUnpaid > 0) {
                showUnpaidResult(totalUnpaid, unpaidCount)
            } else {
                showPaidUpResult()
            }

        } catch (e: Exception) {
            showError("Format de réponse inattendu. Contactez le support.")
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // AFFICHAGE RÉSULTATS
    // ─────────────────────────────────────────────────────────────────────────

    private fun showPaidUpResult() {
        binding.cardResult.visibility = View.VISIBLE
        binding.cardResult.backgroundTintList =
            ContextCompat.getColorStateList(this, R.color.success_container)

        binding.ivResultIcon.setImageResource(R.drawable.ic_check_circle)
        binding.ivResultIcon.imageTintList =
            ContextCompat.getColorStateList(this, R.color.success)

        binding.tvResultStatus.text = "✅ Compte à jour"
        binding.tvResultStatus.setTextColor(ContextCompat.getColor(this, R.color.success))

        binding.tvResultAmount.text = "Aucun impayé détecté"
        binding.tvResultAmount.setTextColor(ContextCompat.getColor(this, R.color.success))

        binding.tvResultDetails.text = "Toutes vos factures sont réglées.\nMerci pour votre ponctualité !"
    }

    private fun showUnpaidResult(total: Long, count: Int) {
        binding.cardResult.visibility = View.VISIBLE
        binding.cardResult.backgroundTintList =
            ContextCompat.getColorStateList(this, R.color.error_container)

        binding.ivResultIcon.setImageResource(R.drawable.ic_error)
        binding.ivResultIcon.imageTintList =
            ContextCompat.getColorStateList(this, R.color.error)

        binding.tvResultStatus.text = "⚠️ Impayé détecté"
        binding.tvResultStatus.setTextColor(ContextCompat.getColor(this, R.color.error))

        binding.tvResultAmount.text = "Montant dû : ${formatAmount(total)} FCFA"
        binding.tvResultAmount.setTextColor(ContextCompat.getColor(this, R.color.error))

        val countText = if (count > 1) "$count factures impayées" else "1 facture impayée"
        binding.tvResultDetails.text = "$countText\nPayez via les canaux officiels SONEB."
    }

    private fun showError(message: String) {
        binding.cardResult.visibility = View.VISIBLE
        binding.cardResult.backgroundTintList =
            ContextCompat.getColorStateList(this, R.color.surface_variant)

        binding.ivResultIcon.setImageResource(R.drawable.ic_warning)
        binding.ivResultIcon.imageTintList =
            ContextCompat.getColorStateList(this, R.color.on_surface_variant)

        binding.tvResultStatus.text = "Vérification impossible"
        binding.tvResultStatus.setTextColor(ContextCompat.getColor(this, R.color.on_surface))

        binding.tvResultAmount.text = message
        binding.tvResultAmount.setTextColor(
            ContextCompat.getColor(this, R.color.on_surface_variant)
        )

        binding.tvResultDetails.text = ""
    }

    private fun hideResultCard() {
        binding.cardResult.visibility = View.GONE
    }

    private fun showLoading(show: Boolean) {
        binding.progressBar.visibility = if (show) View.VISIBLE else View.GONE
        binding.btnVerify.isEnabled = !show
    }

    private fun formatAmount(amount: Long): String {
        return String.format("%,d", amount).replace(',', ' ')
    }

    // ─────────────────────────────────────────────────────────────────────────
    // WORKMANAGER
    // ─────────────────────────────────────────────────────────────────────────

    private fun requestNotificationPermissionAndSchedule() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            when {
                ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED -> {
                    scheduleWeeklyWork()
                }
                else -> {
                    notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }
        } else {
            scheduleWeeklyWork()
        }
    }

    private fun scheduleWeeklyWork() {
        try {
            val subscriber = prefs.getString("subscriber", "") ?: ""
            if (subscriber.isEmpty()) {
                showToast("Entrez d'abord votre numéro d'abonné")
                return
            }

            val data = workDataOf("subscriber" to subscriber)

            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()

            val request = PeriodicWorkRequestBuilder<BillWorker>(7, TimeUnit.DAYS)
                .setInputData(data)
                .setConstraints(constraints)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.MINUTES)
                .build()

            WorkManager.getInstance(this).enqueueUniquePeriodicWork(
                "soneb_weekly_check",
                ExistingPeriodicWorkPolicy.UPDATE,
                request
            )

            showToast("Alertes hebdomadaires activées ✓")
        } catch (e: Exception) {
            showToast("Impossible de planifier les alertes")
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // NOTIFICATION CHANNEL
    // ─────────────────────────────────────────────────────────────────────────

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "soneb_alert_channel",
                "Alertes Factures SONEB",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifications en cas de facture impayée SONEB"
                enableVibration(true)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // SUPPORT
    // ─────────────────────────────────────────────────────────────────────────

    private fun openWhatsApp() {
        try {
            val number = getString(R.string.whatsapp_number)
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$number"))
            startActivity(intent)
        } catch (e: Exception) {
            showToast("Impossible d'ouvrir WhatsApp")
        }
    }

    private fun openEmail() {
        try {
            val email = getString(R.string.support_email)
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:$email")
                putExtra(Intent.EXTRA_SUBJECT, "Support Soneb Alert")
                putExtra(Intent.EXTRA_TEXT, "Bonjour,\n\n")
            }
            startActivity(Intent.createChooser(intent, "Envoyer un email"))
        } catch (e: Exception) {
            showToast("Aucune application email trouvée")
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
